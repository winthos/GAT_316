Begin by Running the Time_Trial executable.

Playthrough the game, and reach the final stage in the last room (Room 7) to automatically
generate data in the TimeTrialDataGenerator_Data/save folder.

Pressing 1-7 will automatically teleport the player to different rooms in game.
Pressing "G" will automatically generate "dummy" data sets in the save folder.

After generating datasets, open up the included Excel document.

Make sure the developer ribbon is enabled, Open the Developer Tab, go to Macros, then
edit the "ImportAllData" Macro.

Inside that, navigate to the comment that says "Path to CSV files" to be wherever the
TimeTrialDataGenerator_Data/save folder is located on your computer.

After editing that, go to the "Room Summary" Tab and hit the Import Data button to import all
Data Sets. All the different tabs will populate automatically.
